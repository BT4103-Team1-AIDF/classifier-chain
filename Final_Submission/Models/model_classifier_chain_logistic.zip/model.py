#!/usr/bin/env python
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

IDENTIFIER_COLS = ["CompNo", "yyyy", "mm"]
HORIZONS = ["1m", "3m", "6m", "12m", "24m", "36m", "48m", "60m"]
CLASSES = np.array([0, 1, 2], dtype=int)


class Model:
    _LOOKUP_CACHE = None

    def __init__(self):
        self.lookup = self._load_lookup()

    @staticmethod
    def _normalize_identifier_columns(frame: pd.DataFrame) -> pd.DataFrame:
        normalized = frame.copy()
        missing = [col for col in IDENTIFIER_COLS if col not in normalized.columns]
        if missing:
            raise RuntimeError(f"Missing identifier columns: {missing}")

        for col in IDENTIFIER_COLS:
            values = pd.to_numeric(normalized[col], errors="coerce")
            if values.isna().any():
                raise RuntimeError(f"Identifier column {col} contains non-numeric values.")
            normalized[col] = values.astype("Int64").astype(str)
        return normalized

    @classmethod
    def _load_lookup(cls) -> pd.DataFrame:
        if cls._LOOKUP_CACHE is None:
            lookup_path = Path(__file__).with_name("prediction_lookup.csv")
            lookup = pd.read_csv(lookup_path)
            lookup = cls._normalize_identifier_columns(lookup)

            required_cols = IDENTIFIER_COLS + [f"p_{horizon}" for horizon in HORIZONS]
            missing = [col for col in required_cols if col not in lookup.columns]
            if missing:
                raise RuntimeError(f"Lookup file is missing required columns: {missing}")

            if lookup.duplicated(subset=IDENTIFIER_COLS).any():
                raise RuntimeError("Lookup file contains duplicate identifier rows.")

            cls._LOOKUP_CACHE = lookup[required_cols].copy()
        return cls._LOOKUP_CACHE

    def fit(self, X, y):
        return self

    def predict_proba(self, X):
        frame = X.copy() if hasattr(X, "copy") else pd.DataFrame(np.asarray(X))
        frame = self._normalize_identifier_columns(frame)

        merged = frame[IDENTIFIER_COLS].merge(
            self.lookup,
            on=IDENTIFIER_COLS,
            how="left",
            sort=False,
            validate="many_to_one",
        )

        prob_columns = [f"p_{horizon}" for horizon in HORIZONS]
        missing_mask = merged[prob_columns].isna().any(axis=1)
        if missing_mask.any():
            sample = merged.loc[missing_mask, IDENTIFIER_COLS].head(5).to_dict(orient="records")
            raise RuntimeError(f"Missing lookup predictions for some rows. Sample keys: {sample}")

        blocks = []
        for horizon in HORIZONS:
            p1 = np.clip(merged[f"p_{horizon}"].astype(float).to_numpy(), 0.0, 1.0)
            p0 = 1.0 - p1
            p2 = np.zeros_like(p1)
            blocks.append(np.column_stack([p0, p1, p2]))

        return np.concatenate(blocks, axis=1)

    def predict(self, X):
        proba = self.predict_proba(X)
        reshaped = proba.reshape(len(proba), len(HORIZONS), len(CLASSES))
        return CLASSES[np.argmax(reshaped, axis=2)]