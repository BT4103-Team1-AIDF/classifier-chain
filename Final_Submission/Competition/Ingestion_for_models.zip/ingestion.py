#!/usr/bin/env python
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

IDENTIFIER_COLS = ["CompNo", "yyyy", "mm"]
HORIZONS = ["1m", "3m", "6m", "12m", "24m", "36m", "48m", "60m"]
CLASSES = [0, 1, 2]
TARGET_COLS = [f"y_{horizon}" for horizon in HORIZONS]


def _pick_one(paths: list[Path], kind: str) -> Path:
    if not paths:
        raise RuntimeError(f"No {kind} file found.")
    paths = sorted(paths, key=lambda p: (len(p.name), p.name.lower(), str(p)))
    return paths[0]


def _is_train_name(path: Path) -> bool:
    name = path.name.lower()
    return name == "train.csv" or name.startswith("train_") or "train" in name


def _is_test_name(path: Path) -> bool:
    name = path.name.lower()
    return name == "test.csv" or name.startswith("test_") or "test" in name


def _find_prediction_features(input_dir: Path) -> Path:
    csv_paths = sorted(path for path in input_dir.rglob("*.csv") if path.is_file())

    exact_test = [path for path in csv_paths if path.name.lower() == "test.csv"]
    if exact_test:
        return _pick_one(exact_test, "test")

    named_test = [path for path in csv_paths if _is_test_name(path)]
    if named_test:
        return _pick_one(named_test, "test")

    exact_features = [path for path in csv_paths if path.name.lower() == "features.csv"]
    if exact_features:
        return _pick_one(exact_features, "features")

    named_features = [path for path in csv_paths if path.name.lower().startswith("features")]
    if named_features:
        return _pick_one(named_features, "features")

    raise RuntimeError("No prediction-side CSV found. Expected test*.csv or features*.csv.")


def _find_training_data(input_dir: Path) -> Path | None:
    csv_paths = sorted(path for path in input_dir.rglob("*.csv") if path.is_file())

    exact_train = [path for path in csv_paths if path.name.lower() == "train.csv"]
    if exact_train:
        return _pick_one(exact_train, "train")

    named_train = [path for path in csv_paths if _is_train_name(path)]
    if named_train:
        return _pick_one(named_train, "train")

    return None


def _prepare_training_frame(train_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    missing_targets = [col for col in TARGET_COLS if col not in train_df.columns]
    if missing_targets:
        raise RuntimeError(f"Training CSV is missing required label columns: {missing_targets}")

    X_train = train_df.drop(columns=[col for col in train_df.columns if col.startswith("y_")]).copy()
    y_train = (
        train_df[TARGET_COLS]
        .apply(lambda col: pd.to_numeric(col, errors="coerce"))
        .fillna(0)
        .astype(int)
    )
    return X_train, y_train


def _find_submission_model(submission_dir: Path) -> Path:
    matches = sorted(submission_dir.rglob("model.py"))
    if not matches:
        raise FileNotFoundError(f"Could not find model.py under {submission_dir}")
    return matches[0]


def _load_submission_model(submission_dir: Path):
    model_path = _find_submission_model(submission_dir)
    spec = importlib.util.spec_from_file_location("submission_model", model_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.Model()


def _coerce_probabilities(raw_proba: np.ndarray, n_rows: int) -> np.ndarray:
    raw_proba = np.asarray(raw_proba, dtype=float)
    expected_cols = len(HORIZONS) * len(CLASSES)
    if raw_proba.ndim != 2 or raw_proba.shape != (n_rows, expected_cols):
        raise RuntimeError(
            f"predict_proba must return shape ({n_rows}, {expected_cols}) for 8 horizons x 3 classes. Got {raw_proba.shape}."
        )
    return raw_proba


def _coerce_predictions(raw_pred: np.ndarray, n_rows: int, reshaped_proba: np.ndarray) -> np.ndarray:
    raw_pred = np.asarray(raw_pred)
    if raw_pred.ndim == 2 and raw_pred.shape == (n_rows, len(HORIZONS)):
        return raw_pred.astype(int)

    class_values = np.asarray(CLASSES, dtype=int)
    return class_values[np.argmax(reshaped_proba, axis=2)]


def main(input_dir: str, output_dir: str, submission_dir: str) -> None:
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    submission_path = Path(submission_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    features_path = _find_prediction_features(input_path)
    features = pd.read_csv(features_path)

    missing_ids = [col for col in IDENTIFIER_COLS if col not in features.columns]
    if missing_ids:
        raise RuntimeError(f"Required identifier columns missing from prediction features: {missing_ids}")

    model = _load_submission_model(submission_path)

    train_path = _find_training_data(input_path)
    if train_path is not None and hasattr(model, "fit"):
        train_df = pd.read_csv(train_path)
        X_train, y_train = _prepare_training_frame(train_df)
        model.fit(X_train, y_train)

    raw_proba = _coerce_probabilities(model.predict_proba(features.copy()), len(features))
    reshaped_proba = raw_proba.reshape(len(features), len(HORIZONS), len(CLASSES))

    if hasattr(model, "predict"):
        pred = _coerce_predictions(model.predict(features.copy()), len(features), reshaped_proba)
    else:
        pred = _coerce_predictions(np.empty((0, 0)), len(features), reshaped_proba)

    output = features[IDENTIFIER_COLS].copy()
    for idx, horizon in enumerate(HORIZONS):
        output[f"pred_{horizon}"] = pred[:, idx]
        for class_index, class_value in enumerate(CLASSES):
            output[f"p_{horizon}_class_{class_value}"] = reshaped_proba[:, idx, class_index]

    predictions_path = output_path / "predictions.csv"
    output.to_csv(predictions_path, index=False)

    manifest = {
        "features_path": str(features_path),
        "predictions_path": str(predictions_path),
        "num_rows": int(len(output)),
        "horizons": HORIZONS,
        "classes": CLASSES,
    }
    (output_path / "ingestion_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print("Saved predictions to", predictions_path)


if __name__ == "__main__":
    if len(sys.argv) < 4:
        raise SystemExit("Usage: python ingestion.py <input_dir> <output_dir> <submission_dir>")
    main(sys.argv[1], sys.argv[2], sys.argv[3])
