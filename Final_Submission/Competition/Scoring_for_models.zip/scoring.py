import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


IDENTIFIER_COLS = ["CompNo", "yyyy", "mm"]
HORIZONS = ["1m", "3m", "6m", "12m", "24m", "36m", "48m", "60m"]


def safe_auc(y, p):
    y_arr = np.asarray(y).astype(int)
    if np.unique(y_arr).size < 2:
        return float("nan")
    return float(roc_auc_score(y_arr, np.asarray(p, dtype=float)))


def main(input_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)

    ref_dir = os.path.join(input_dir, "ref")
    res_dir = os.path.join(input_dir, "res")

    labels_path = os.path.join(ref_dir, "labels.csv")
    preds_path = os.path.join(res_dir, "predictions.csv")

    if not os.path.exists(labels_path):
        raise FileNotFoundError(f"Missing labels file: {labels_path}")
    if not os.path.exists(preds_path):
        raise FileNotFoundError(f"Missing predictions file: {preds_path}")

    usecols = [*IDENTIFIER_COLS, *[f"y_{h}" for h in HORIZONS]]
    labels = pd.read_csv(labels_path, usecols=usecols)
    preds = pd.read_csv(preds_path)

    required_pred_cols = [*IDENTIFIER_COLS, *[f"p_{h}_class_1" for h in HORIZONS]]
    missing_pred = [c for c in required_pred_cols if c not in preds.columns]
    if missing_pred:
        raise KeyError(f"Missing prediction columns: {missing_pred}")

    if labels.duplicated(subset=IDENTIFIER_COLS).any():
        raise ValueError("Reference labels contain duplicate identifier rows.")
    if preds.duplicated(subset=IDENTIFIER_COLS).any():
        raise ValueError("Predictions contain duplicate identifier rows.")

    merged = labels.merge(preds, on=IDENTIFIER_COLS, how="inner", validate="one_to_one")
    if merged.empty:
        raise ValueError("No overlapping rows between labels and predictions.")

    rows = []
    auc_values = []
    for horizon in HORIZONS:
        y_binary = (merged[f"y_{horizon}"] == 1).astype(int)
        auc = safe_auc(y_binary, merged[f"p_{horizon}_class_1"])
        rows.append(
            {
                "horizon": horizon,
                "default_auc": auc,
                "n_rows": int(len(merged)),
                "n_default": int(y_binary.sum()),
            }
        )
        if np.isfinite(auc):
            auc_values.append(auc)

    metrics = pd.DataFrame(rows)
    metrics.to_csv(os.path.join(output_dir, "per_horizon_metrics.csv"), index=False)

    scores = {f"AUC_{h.upper()}": row["default_auc"] for h, row in zip(HORIZONS, rows)}
    scores["AUC_MEAN_8H"] = float(np.mean(auc_values)) if auc_values else float("nan")

    with open(os.path.join(output_dir, "scores.json"), "w", encoding="utf-8") as f:
        json.dump(scores, f, indent=2)

    with open(os.path.join(output_dir, "scores.txt"), "w", encoding="utf-8") as f:
        for key, value in scores.items():
            f.write(f"{key}: {value}\n")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
