import glob
import os
import sys
from typing import Optional

import numpy as np
import pandas as pd


IDENTIFIER_COLS = ["CompNo", "yyyy", "mm"]
HORIZONS = ["1m", "3m", "6m", "12m", "24m", "36m", "48m", "60m"]
TARGET_COLS = [f"y_{horizon}" for horizon in HORIZONS]


def _pick_one(paths, kind: str) -> str:
    if not paths:
        raise RuntimeError(f"No {kind} file found. Expected something like '{kind}*.csv'.")
    paths = sorted(paths, key=lambda p: (len(os.path.basename(p)), os.path.basename(p)))
    return paths[0]


def _coerce_probabilities(raw_proba: np.ndarray, n_rows: int) -> np.ndarray:
    raw_proba = np.asarray(raw_proba, dtype=float)
    if raw_proba.ndim != 2 or raw_proba.shape[0] != n_rows:
        raise RuntimeError(
            f"predict_proba must return a 2D array with {n_rows} rows. Got {raw_proba.shape}."
        )
    expected_cols = len(HORIZONS) * 3
    if raw_proba.shape[1] != expected_cols:
        raise RuntimeError(
            f"predict_proba must return shape (n_rows, {expected_cols}) for 8 horizons x 3 classes. "
            f"Got {raw_proba.shape}."
        )
    return raw_proba


def _is_train_name(path: str) -> bool:
    name = os.path.basename(path).lower()
    return name == "train.csv" or name.startswith("train_") or "train" in name


def _is_test_name(path: str) -> bool:
    name = os.path.basename(path).lower()
    return name.startswith("test_") or "test" in name


def _pick_prediction_features(input_dir: str) -> str:
    csv_paths = sorted(glob.glob(os.path.join(input_dir, "*.csv")))
    test_paths = [path for path in csv_paths if _is_test_name(path)]
    if test_paths:
        return _pick_one(test_paths, "test")

    feature_paths = glob.glob(os.path.join(input_dir, "features*.csv"))
    if feature_paths:
        return _pick_one(feature_paths, "features")

    raise RuntimeError("No prediction-side CSV found. Expected test*.csv or features*.csv.")


def _pick_training_data(input_dir: str) -> Optional[str]:
    csv_paths = sorted(glob.glob(os.path.join(input_dir, "*.csv")))
    labeled_train = [path for path in csv_paths if os.path.basename(path).lower() == "train.csv"]
    if labeled_train:
        return labeled_train[0]

    other_train = [path for path in csv_paths if _is_train_name(path)]
    if other_train:
        return _pick_one(other_train, "train")
    return None


def _prepare_training_frame(train_df: pd.DataFrame):
    missing_targets = [col for col in TARGET_COLS if col not in train_df.columns]
    if missing_targets:
        raise RuntimeError(f"Training CSV is missing required label columns: {missing_targets}")

    X_train = train_df.drop(columns=[col for col in train_df.columns if col.startswith("y_")])
    y_train = train_df[TARGET_COLS].apply(lambda col: pd.to_numeric(col, errors="coerce")).fillna(0).astype(int)
    return X_train, y_train


def main(input_dir, output_dir, submission_dir):
    sys.path.insert(0, submission_dir)
    from model import Model

    features_path = _pick_prediction_features(input_dir)
    features = pd.read_csv(features_path)

    missing_ids = [col for col in IDENTIFIER_COLS if col not in features.columns]
    if missing_ids:
        raise RuntimeError(f"Required identifier columns missing from features file: {missing_ids}")

    model = Model()

    train_path = _pick_training_data(input_dir)
    if train_path is not None and hasattr(model, "fit"):
        train_df = pd.read_csv(train_path)
        X_train, y_train = _prepare_training_frame(train_df)
        model.fit(X_train, y_train)

    raw_proba = _coerce_probabilities(model.predict_proba(features.copy()), len(features))

    out = features[IDENTIFIER_COLS].copy()
    reshaped = raw_proba.reshape(len(features), len(HORIZONS), 3)
    for idx, horizon in enumerate(HORIZONS):
        out[f"p1_{horizon}"] = reshaped[:, idx, 1]

    os.makedirs(output_dir, exist_ok=True)
    out.to_csv(os.path.join(output_dir, "predictions.csv"), index=False)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
